# UnlimitedWorldEditBridge

## Overview

UnlimitedWorldEditBridge is a Minecraft Bukkit/Spigot plugin designed to bridge functionality with WorldEdit. The plugin targets Minecraft 1.12 servers running on Beast/Paper forks and aims to extend or modify WorldEdit capabilities.

The project is built using Maven and depends on the WorldEdit Bukkit API. The core functionality involves intercepting WorldEdit commands (like `//walls`) and processing them through custom logic.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Build System
- **Maven** is used as the build tool
- Project coordinates: `me.brumisharuma:UnlimitedWorldEditBridge:1.0`
- Main class located at: `me.brumisharuma.uwebridge.UWEBridge`

### Target Environment
- **Minecraft Version**: 1.12 (uses `v1_12_R1` NMS)
- **Server Software**: Beast/Paper fork (git-Beast-"95dc571")
- **Java**: Modern JDK (based on stack traces)

### Plugin Architecture
- Standard Bukkit plugin structure with command event listeners
- Intercepts player-issued WorldEdit commands via `PlayerCommandPreprocessEvent` or similar
- Processes WorldEdit operations like `//walls` with custom block pattern handling

### Key Technical Challenges

**WorldEdit API Version Mismatch**
- The plugin was built against a newer WorldEdit API that uses `com.sk89q.worldedit.world.block.BlockStateHolder` (WorldEdit 7.x API)
- The target server runs an older WorldEdit version (6.x) that doesn't have this class
- WorldEdit 6.x uses `com.sk89q.worldedit.blocks.BaseBlock` directly instead of the `BlockStateHolder` abstraction

**Pattern API Incompatibility**
- Code attempts to cast `BaseBlock` to `Pattern` interface
- In WorldEdit 6.x, `BaseBlock` does not implement `Pattern` directly
- Need to use `SingleBlockPattern` wrapper or the legacy pattern system

### Required Fixes
1. Use WorldEdit 6.1.x compatible dependency (`com.sk89q.worldedit:worldedit-bukkit:6.1.5` or similar from sk89q-repo)
2. Add the sk89q Maven repository to pom.xml
3. Refactor code to use WorldEdit 6.x APIs:
   - Use `BaseBlock` instead of `BlockStateHolder`
   - Use `SingleBlockPattern` to wrap blocks as patterns
   - Use legacy block parsing methods

## External Dependencies

### Maven Repositories Required
- **Maven Central**: Standard Java dependencies
- **sk89q Repository**: `https://maven.enginehub.org/repo/` - Required for WorldEdit artifacts

### Plugin Dependencies
| Dependency | Version | Purpose |
|------------|---------|---------|
| Bukkit/Spigot API | 1.12.2-R0.1 | Server plugin API |
| WorldEdit Bukkit | 6.1.x | World manipulation API (must match server's installed version) |

### Runtime Requirements
- WorldEdit plugin must be installed on the server
- Server must be running Bukkit/Spigot/Paper 1.12.x
- WorldEdit version on server must be 6.x (not 7.x) based on the API classes available